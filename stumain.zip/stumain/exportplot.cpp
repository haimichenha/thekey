#include "exportplot.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>

ExportPlot::ExportPlot(QWidget *parent) : QDialog(parent)
{
    setWindowTitle("导出设置");

    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    QLabel *label = new QLabel("选择背景颜色:", this);

    blackBgButton = new QRadioButton("绿色背景", this);
    transparentBgButton = new QRadioButton("透明背景", this);
    transparentBgButton->setChecked(true);

    confirmButton = new QPushButton("确定", this);

    mainLayout->addWidget(label);
    mainLayout->addWidget(blackBgButton);
    mainLayout->addWidget(transparentBgButton);
    mainLayout->addWidget(confirmButton);

    connect(confirmButton, &QPushButton::clicked, this, &QDialog::accept);

    setFixedSize(200, 150);
}

bool ExportPlot::isTransparentBackground() const
{
    return transparentBgButton->isChecked();
}
