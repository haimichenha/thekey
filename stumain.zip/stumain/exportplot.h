#ifndef EXPORTPLOT_H
#define EXPORTPLOT_H

#include <QDialog>
#include <QRadioButton>
#include <QPushButton>

class ExportPlot : public QDialog
{
    Q_OBJECT
public:
    explicit ExportPlot(QWidget *parent = nullptr);
    bool isTransparentBackground() const;

private:
    QRadioButton *blackBgButton;
    QRadioButton *transparentBgButton;
    QPushButton *confirmButton;
};

#endif // EXPORTPLOT_H
